package chapter0702;

public class LoginServlet extends HttpServlet {
	@Override
	public void service() {
		System.out.println("로그인합니다");
	}
}
