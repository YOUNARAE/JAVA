package chapter0702;

public abstract class HttpServlet {
	public abstract void service();
}
