package chapter07;

public class ComputerExample {

	public static void main(String[] args) {
//		Calculator calculator = new Calculator();
//		System.out.println(calculator.areaCircle(10));
//		
//		System.out.println();
		
		Computer computer = new Computer();
		System.out.println(computer.areaCircle(10));
	}

}
