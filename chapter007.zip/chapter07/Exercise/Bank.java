package chapter07.Exercise;

public class Bank {
	Customer[] customers;
	int numberOfCustomers;
	
	//생성자
	public Bank() {
	}
	
	//메소드
	public void addCustomer() {
	}

	public Customer[] getCustomers() {
		return customers;
	}

	public int getNumberOfCustomers() {
		return numberOfCustomers;
	}
	
	public Customer getCustomer(int Customer) {
		return 0;
	}
	
	
	
}
