package chapter07.Exercise;

public class Shape {
	//필드
	//생성자
	//메소드
	public double area(){
		return 0.0;
	}
	public double perimeter() {
	   return 0.0;
	}

}
