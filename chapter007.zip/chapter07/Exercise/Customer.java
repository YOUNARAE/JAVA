package chapter07.Exercise;

public class Customer {
	//메서드
	private String firstName;
	private String lastName;
	private BankAccount account;
	
	
	//생성자
	public Customer(String firstname, String lastname) {
		this.firstName = firstname;
		this.lastName = lastname;
	}
	
	//메소드
	public String getFirstName() {
		return "";
	}
	
	public String getLastName() {
		return "";
	}
	
	public void getAccount(){
		return;
	}

}
