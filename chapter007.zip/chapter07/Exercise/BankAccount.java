package chapter07.Exercise;

public class BankAccount {
	private int balance;
	
	 public BankAccount() { 
	 }
	 
	 public BankAccount(int bankaccount) {
		 
	 }
	 
	 public int getBalance() {
		 return 0;
	 }
	 
	 public void deposit(int deposit) {
		 deposit = deposit;
	 }
	 public boolean withdraw(int withdraw) {
		 return true;
	 }
	 public boolean transger(int tranger, int bankaccount) {
		 return true;
	 }

}

